<?php return array(
    'root' => array(
        'pretty_version' => '1.0.0',
        'version' => '1.0.0.0',
        'type' => 'wordpress-plugin',
        'install_path' => __DIR__ . '/../../',
        'aliases' => array(),
        'reference' => NULL,
        'name' => 'kdu/paygol-woocommerce',
        'dev' => true,
    ),
    'versions' => array(
        'kdu/paygol-woocommerce' => array(
            'pretty_version' => '1.0.0',
            'version' => '1.0.0.0',
            'type' => 'wordpress-plugin',
            'install_path' => __DIR__ . '/../../',
            'aliases' => array(),
            'reference' => NULL,
            'dev_requirement' => false,
        ),
        'kdu/paygolcore' => array(
            'pretty_version' => '1.0.0',
            'version' => '1.0.0.0',
            'type' => 'library',
            'install_path' => __DIR__ . '/../kdu/paygolcore',
            'aliases' => array(),
            'reference' => 'a6475af7c71f5eac149780aeee0dc73852d41c65',
            'dev_requirement' => false,
        ),
    ),
);
